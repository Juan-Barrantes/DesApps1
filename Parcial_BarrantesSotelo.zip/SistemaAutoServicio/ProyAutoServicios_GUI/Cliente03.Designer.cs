﻿
namespace ProyAutoServicios_GUI
{
    partial class Cliente03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpDatos = new System.Windows.Forms.GroupBox();
            this.txtTipoDoc = new System.Windows.Forms.TextBox();
            this.txtDocIdent = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textTel = new System.Windows.Forms.TextBox();
            this.textDir = new System.Windows.Forms.TextBox();
            this.btnGrabar = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.txtApe = new System.Windows.Forms.TextBox();
            this.txtNom = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.grpDatos.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpDatos
            // 
            this.grpDatos.Controls.Add(this.txtTipoDoc);
            this.grpDatos.Controls.Add(this.txtDocIdent);
            this.grpDatos.Controls.Add(this.label4);
            this.grpDatos.Controls.Add(this.textTel);
            this.grpDatos.Controls.Add(this.textDir);
            this.grpDatos.Controls.Add(this.btnGrabar);
            this.grpDatos.Controls.Add(this.label9);
            this.grpDatos.Controls.Add(this.Label1);
            this.grpDatos.Controls.Add(this.txtApe);
            this.grpDatos.Controls.Add(this.txtNom);
            this.grpDatos.Controls.Add(this.Label2);
            this.grpDatos.Controls.Add(this.label7);
            this.grpDatos.Controls.Add(this.Label3);
            this.grpDatos.Controls.Add(this.btnCancelar);
            this.grpDatos.Location = new System.Drawing.Point(23, 23);
            this.grpDatos.Margin = new System.Windows.Forms.Padding(4);
            this.grpDatos.Name = "grpDatos";
            this.grpDatos.Padding = new System.Windows.Forms.Padding(4);
            this.grpDatos.Size = new System.Drawing.Size(531, 346);
            this.grpDatos.TabIndex = 3;
            this.grpDatos.TabStop = false;
            this.grpDatos.Text = "Datos";
            // 
            // txtTipoDoc
            // 
            this.txtTipoDoc.Location = new System.Drawing.Point(140, 79);
            this.txtTipoDoc.Margin = new System.Windows.Forms.Padding(4);
            this.txtTipoDoc.Name = "txtTipoDoc";
            this.txtTipoDoc.Size = new System.Drawing.Size(229, 22);
            this.txtTipoDoc.TabIndex = 12;
            // 
            // txtDocIdent
            // 
            this.txtDocIdent.Location = new System.Drawing.Point(140, 36);
            this.txtDocIdent.Margin = new System.Windows.Forms.Padding(4);
            this.txtDocIdent.Name = "txtDocIdent";
            this.txtDocIdent.Size = new System.Drawing.Size(229, 22);
            this.txtDocIdent.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(11, 239);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "Telefono:";
            // 
            // textTel
            // 
            this.textTel.Location = new System.Drawing.Point(140, 234);
            this.textTel.Margin = new System.Windows.Forms.Padding(4);
            this.textTel.Name = "textTel";
            this.textTel.Size = new System.Drawing.Size(117, 22);
            this.textTel.TabIndex = 8;
            // 
            // textDir
            // 
            this.textDir.Location = new System.Drawing.Point(140, 193);
            this.textDir.Margin = new System.Windows.Forms.Padding(4);
            this.textDir.Name = "textDir";
            this.textDir.Size = new System.Drawing.Size(117, 22);
            this.textDir.TabIndex = 7;
            // 
            // btnGrabar
            // 
            this.btnGrabar.Location = new System.Drawing.Point(391, 282);
            this.btnGrabar.Margin = new System.Windows.Forms.Padding(4);
            this.btnGrabar.Name = "btnGrabar";
            this.btnGrabar.Size = new System.Drawing.Size(96, 30);
            this.btnGrabar.TabIndex = 5;
            this.btnGrabar.Text = "Grabar";
            this.btnGrabar.Click += new System.EventHandler(this.btnGrabar_Click);
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(11, 39);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 25);
            this.label9.TabIndex = 3;
            this.label9.Text = "DocIdentidad:";
            // 
            // Label1
            // 
            this.Label1.Location = new System.Drawing.Point(11, 82);
            this.Label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(121, 25);
            this.Label1.TabIndex = 3;
            this.Label1.Text = "TipoDocumento:";
            // 
            // txtApe
            // 
            this.txtApe.Location = new System.Drawing.Point(140, 121);
            this.txtApe.Margin = new System.Windows.Forms.Padding(4);
            this.txtApe.Name = "txtApe";
            this.txtApe.Size = new System.Drawing.Size(229, 22);
            this.txtApe.TabIndex = 1;
            // 
            // txtNom
            // 
            this.txtNom.Location = new System.Drawing.Point(140, 159);
            this.txtNom.Margin = new System.Windows.Forms.Padding(4);
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(117, 22);
            this.txtNom.TabIndex = 2;
            // 
            // Label2
            // 
            this.Label2.Location = new System.Drawing.Point(11, 118);
            this.Label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(85, 20);
            this.Label2.TabIndex = 3;
            this.Label2.Text = "Apellidos:";
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(11, 197);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 20);
            this.label7.TabIndex = 3;
            this.label7.Text = "Direccion:";
            // 
            // Label3
            // 
            this.Label3.Location = new System.Drawing.Point(11, 159);
            this.Label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(85, 20);
            this.Label3.TabIndex = 3;
            this.Label3.Text = "Nombres:";
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(275, 282);
            this.btnCancelar.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(96, 30);
            this.btnCancelar.TabIndex = 6;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // Cliente03
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(587, 397);
            this.Controls.Add(this.grpDatos);
            this.Name = "Cliente03";
            this.Text = "Cliente03";
            this.Load += new System.EventHandler(this.Cliente03_Load);
            this.grpDatos.ResumeLayout(false);
            this.grpDatos.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.GroupBox grpDatos;
        internal System.Windows.Forms.TextBox txtTipoDoc;
        internal System.Windows.Forms.TextBox txtDocIdent;
        internal System.Windows.Forms.Label label4;
        internal System.Windows.Forms.TextBox textTel;
        internal System.Windows.Forms.TextBox textDir;
        internal System.Windows.Forms.Button btnGrabar;
        internal System.Windows.Forms.Label label9;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox txtApe;
        internal System.Windows.Forms.TextBox txtNom;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label label7;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Button btnCancelar;
    }
}